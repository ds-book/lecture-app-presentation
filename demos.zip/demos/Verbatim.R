library(shiny)
library(bslib)


  shinyApp(
    ui = basicPage(
      textInput("txt", "Enter the text to display below:"),
      textOutput("default"),
      verbatimTextOutput("default")
    ),
    server = function(input, output) {
      output$default <- renderText({ input$txt })
      output$placeholder <- renderText({ input$txt })
    }
  )
